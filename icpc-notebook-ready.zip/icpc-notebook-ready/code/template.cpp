// Fast IO + common macros
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define all(x) begin(x), end(x)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    // ...
    return 0;
}
